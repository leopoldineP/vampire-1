/*
   qvoronoi.hpp
     header for integrating qvoronoi into vampire
*/
#ifndef QVORONOI
#define QVORONOI
#include <stdio.h>

void qvoronoi(int , char *[], FILE* , FILE* );

#endif
